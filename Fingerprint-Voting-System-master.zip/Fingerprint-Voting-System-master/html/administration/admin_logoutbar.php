<html>
    <div class="row">
        <div class="col-md-12 option">
            <a href="admin_logout.php" onclick="return confirm('Are you sure you want to logout?.');" ><i class="fas fa-sign-out-alt fa-2x" data-toggle="tooltip" data-placement="top" title="Sign Out"></i></a>
            <a href="admin_editProfile.php"><i class="fas fa-user-edit fa-2x" data-toggle="tooltip" data-placement="top" title="Edit Profile"></i></a>
            <a href="admin_profile.php"><i class="fas fa-user fa-2x" data-toggle="tooltip" data-placement="top" title="Profile"></i></a>
        </div>
    </div>
</html>