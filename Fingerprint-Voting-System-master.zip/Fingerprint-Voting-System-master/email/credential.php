<?php

return [
    'user' => 'chefguruhotel@gmail.com',
    'pass' => 'Admin@chefguru'
];

?>